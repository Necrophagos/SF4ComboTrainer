﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF4ComboTrainerModel
{
    public enum Input
    {
        P1_LE,
        P1_RI,
        P1_BK,
        P1_FW,
        P1_DN,
        P1_UP,
        P1_LP,
        P1_MP,
        P1_HP,
        P1_LK,
        P1_MK,
        P1_HK
    }
}
