using System;
namespace TPInputLibrary
{
    public abstract class SF4InputConverter
    {
        public abstract SF4InputState Convert(); 
    }               
}

