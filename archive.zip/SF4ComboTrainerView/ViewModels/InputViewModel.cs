﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SF4ComboTrainerModel;

namespace SF4ComboTrainerView
{
    class InputViewModel
    {
        Input[] inputs;

    }
}
